let addToDoButton = document.getElementById("addToDo");
let container = document.getElementById("toDoContainer");
let input = document.getElementById("inputField");
 
addToDoButton.addEventListener("click", function(){
var paragraph = document.createElement("p");
paragraph.classList.add("paragraph-styling")
paragraph.innerHTML = input.value;
container.appendChild(paragraph);
input.value = "";
paragraph.addEventListener("click", function(){
    paragraph.style.textDecoration = "line-through"
});
paragraph.addEventListener("dblclick", function(){
    paragraph.remove();
})


});